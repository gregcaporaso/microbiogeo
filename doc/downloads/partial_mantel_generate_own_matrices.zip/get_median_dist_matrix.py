#!/usr/bin/env python
# File created on 30 Jan 2012
from __future__ import division

__author__ = "Michael Dwan"
__copyright__ = "Copyright 2011, The QIIME project"
__credits__ = ["Michael Dwan"]
__license__ = "GPL"
__version__ = "1.4.0-dev"
__maintainer__ = "Michael Dwan"
__email__ = "mgd25@nau.edu"
__status__ = "Development"
 

from qiime.util import parse_command_line_parameters, make_option
from math import sqrt
from keyboard_xy import keyboard_xy_map


script_info = {}
script_info['brief_description'] = ""
script_info['script_description'] = ""
script_info['script_usage'] = [("","","")]
script_info['output_description']= ""
script_info['required_options'] = [
 # Example required option
 make_option('-i','--input_file',type="existing_filepath",help='the input comparisons file'),
 make_option('-m','--matrix_file',type="existing_filepath",help='the input distance matrix'),
]
script_info['optional_options'] = [
 # Example optional option
 make_option('-o','--output_file',type="new_filepath",help='the output file name [default: %default]'),
]
script_info['version'] = __version__


def main():
  option_parser, opts, args = parse_command_line_parameters(**script_info)

  comparisons = {}
  in_file = open(opts.input_file)
  for line in in_file:
    split_line = line.split()
    comparisons[split_line[0]] = split_line[1:]
   
  #print comparisons

  in_file_mtx = open(opts.matrix_file)
  headers = next(in_file_mtx).split()

  dist_mtx = [[h for h in headers]]
  for h in headers:
    dist_mtx.append([0 for j in range(len(headers)+1)])
  l = 0 
  for i in range(0,len(headers)):
    dist_mtx[i+1][0] = dist_mtx[0][i]
    for k in range(l, len(headers)):
      smpl_id_ref1 = headers[i][:2]
      smpl_id_ref2 = headers[k][:2]
      if headers[i] == headers[k]:
        #if smpl_id_ref1 == smpl_id_ref2:
        dist_mtx[i+1][k+1] = 0
        continue
   
      #cmp_ref = smpl_id_ref1+'_vs._'+smpl_id_ref2
      if smpl_id_ref1+'_vs._'+smpl_id_ref2 in comparisons.keys():
        cmp_ref = smpl_id_ref1+'_vs._'+smpl_id_ref2
      else:
        cmp_ref = smpl_id_ref2+'_vs._'+smpl_id_ref1

      val = comparisons[cmp_ref].pop(0)
      dist_mtx[i+1][k+1] = val
      dist_mtx[k+1][i+1] = val
    l+=1


  out_str = "\t"
  for row in dist_mtx:
    for el in row:
      out_str += '{}\t'.format(el)

    out_str = out_str[:-1] + '\n'

  file_out = open(opts.output_file, 'w')

  file_out.write(out_str)

  #print dist_mtx
  #print get_dist(keyboard_xy_map[my_list[0][1]], keyboard_xy_map[my_list[9][1]])


if __name__ == "__main__":
  main()

